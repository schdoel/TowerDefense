//
//  EnemyDotBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemySecondBullet_hpp
#define EnemySecondBullet_hpp
#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemySecondBullet : public iEnemyBullet {
public:
    explicit EnemySecondBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemySecondBullet_hpp */
