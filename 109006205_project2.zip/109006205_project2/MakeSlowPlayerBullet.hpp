//
//  MakeSlowPlayerBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef MakeSlowPlayerBullet_hpp
#define MakeSlowPlayerBullet_hpp

#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class MakeSlowPlayerBullet : public Bullet {
public:
    explicit MakeSlowPlayerBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* MakeSlowPlayerBullet_hpp */
