//
//  ShieldTurret.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef ShieldTurret_hpp
#define ShieldTurret_hpp

#include "Turret.hpp"

class ShieldTurret: public Turret {
public:
    static const int Price;
    ShieldTurret(float x, float y);
    void CreateBullet() override;
};

#endif /* ShieldTurret_hpp */
