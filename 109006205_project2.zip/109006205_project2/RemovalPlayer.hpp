//
//  RemovalPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef RemovalPlayer_hpp
#define RemovalPlayer_hpp

#include "Turret.hpp"

class RemovalPlayer: public Turret {
public:
    static const int Price;
    RemovalPlayer(float x, float y);
    void CreateBullet() override;
    void Update(float deltaTime) override;
};

#endif /* RemovalPlayer_hpp */
