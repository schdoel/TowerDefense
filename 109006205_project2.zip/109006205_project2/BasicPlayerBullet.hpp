//
//  BasicPlayerBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef BasicPlayerBullet_hpp
#define BasicPlayerBullet_hpp

#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class BasicPlayerBullet : public Bullet {
public:
    explicit BasicPlayerBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* BasicPlayerBullet_hpp */
