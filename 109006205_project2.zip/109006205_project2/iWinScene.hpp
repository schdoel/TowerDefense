#ifndef IWINSCENE_HPP
#define IWINSCENE_HPP
#include <allegro5/allegro_audio.h>
#include "IScene.hpp"

class iWinScene final : public Engine::IScene {
private:
	float ticks;
	ALLEGRO_SAMPLE_ID bgmId;
public:
	explicit iWinScene() = default;
	void Initialize() override;
	void Terminate() override;
	void Update(float deltaTime) override;
	void BackOnClick(int stage);
};

#endif // IWINSCENE_HPP
