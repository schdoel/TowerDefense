#include <string>

#include "AudioHelper.hpp"
#include "EnemySixthBullet.hpp"
#include "TAKuoEnemy.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "StrongEnemy.hpp"

TAKuoEnemy::TAKuoEnemy(int x, int y) : Enemy("play/ienemy-6.png", x, y, 120, 20, 150, 50, 1) {
	// Use bounding circle to detect collision is for simplicity, pixel-perfect collision can be implemented quite easily,
	// and efficiently if we use AABB collision detection first, and then pixel-perfect collision.
}

void TAKuoEnemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemySixthBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
