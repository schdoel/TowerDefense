#include <string>

#include "AudioHelper.hpp"
#include "EnemySecondBullet.hpp"
#include "iEnemyBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"

#include "TA2Enemy.hpp"

TA2Enemy::TA2Enemy(int x, int y) : Enemy("play/ienemy-2.png", x, y, 10, 75, 5, 5, 5) {
    // TODO 2 (6/8): You can imitate the 2 files: 'NormalEnemy.hpp', 'NormalEnemy.cpp' to create a new enemy.
}
void TA2Enemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemySecondBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
