//
//  AnotherPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef AnotherPlayer_hpp
#define AnotherPlayer_hpp

#include "Turret.hpp"

class AnotherPlayer: public Turret {
public:
    static const int Price;
    AnotherPlayer(float x, float y);
    void CreateBullet() override;
};
#endif /* AnotherPlayer_hpp */
