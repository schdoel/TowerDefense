//
//  AnotherTurret.cpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#include "AnotherTurret.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"
#include "DoubleDotBullet.hpp"

const int AnotherTurret::Price = 80;
AnotherTurret::AnotherTurret(float x, float y) :
Turret("play/turret-4.png", x, y,30, 50, Price, 0.5){}

void AnotherTurret::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
//    getPlayScene()->BulletGroup->AddNewObject(new DoubleDotBullet(Position , diff, rotation, this));
//    AudioHelper::PlayAudio("gun.wav");
}
