#include <functional>
#include <memory>
#include <string>

#include "GameEngine.hpp"
#include "ImageButton.hpp"
#include "Label.hpp"
#include "Point.hpp"
#include "Resources.hpp"
#include "Start_Scene.hpp"
#include "StageSelectScene.hpp"
#include "intro.hpp"
#include "intro2.hpp"
#include "intro3.hpp"
#include "intro4.hpp"
#include "intro5.hpp"
#include "intro6.hpp"
/*
 #include <allegro5/color.h>
 #include <allegro5/allegro_primitives.h>
 #include <cmath>
 #include <random>
 #include <string>
 #include <vector>
 #include <utility>

 #include "AudioHelper.hpp"
 #include "Collider.hpp"
 #include "Enemy.hpp"
 #include "GameEngine.hpp"
 #include "Group.hpp"
 #include "IObject.hpp"
 #include "IScene.hpp"
 #include "PlayScene.hpp"
 #include "Point.hpp"
 #include "Turret.hpp"
 #include "ShootEffect.hpp"
 #include "Bullet.hpp"
 #include "LOG.hpp"
 #include "ExplosionEffect.hpp"

 */
void StartScene::Initialize() {
    int w = Engine::GameEngine::GetInstance().GetScreenSize().x;
    int h = Engine::GameEngine::GetInstance().GetScreenSize().y;
    int halfW = w / 2;
    int halfH = h / 2;
    
    //intro(halfW,halfH);
    
    
    Engine::ImageButton* btn;

    btn = new Engine::ImageButton("start_scene/out.png", "start_scene/in.png", halfW - 200, halfH-30 , 400, 100);
    btn->SetOnClickCallback(std::bind(&StartScene::PlayOnClick, this, 1));
    AddNewControlObject(btn);
    AddNewObject(new Engine::Label("Play", "slkscr.ttf", 48, halfW, halfH +20 , 0, 0, 0, 255, 0.5, 0.5));
    AddNewObject(new Engine::Label("Zombie Defense", "slkscr.ttf", 108, halfW, halfH/2 + 60 , 255, 255, 0, 255, 0.5, 0.5));
    
    AddNewObject(new intro(halfW - 75, halfH*1.5));
    AddNewObject(new intro2(halfW - 225, halfH*1.5));
    AddNewObject(new intro3(halfW - 375, halfH*1.5));
    AddNewObject(new intro4(halfW + 75, halfH*1.5));
    AddNewObject(new intro5(halfW + 225, halfH*1.5));
    AddNewObject(new intro6(halfW + 375, halfH*1.5));
}
void StartScene::Terminate() {
	IScene::Terminate();
}
void StartScene::PlayOnClick(int stage) {
    Engine::GameEngine::GetInstance().ChangeScene("stage-select");
}
/*const int PlayScene::MapWidth = 12, PlayScene::MapHeight = 6;//50;//13;
 const int PlayScene::BlockSize = 128;*/
