//
//  EnemyFryBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyFifthBullet_hpp
#define EnemyFifthBullet_hpp

#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyFifthBullet : public iEnemyBullet {
public:
    explicit EnemyFifthBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyFifthBullet_hpp */
