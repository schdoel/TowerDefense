//
//  ExtraTurret.cpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#include "ExtraTurret.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"
#include "DoubleDotBullet.hpp"

const int ExtraTurret::Price = 80;
ExtraTurret::ExtraTurret(float x, float y) :
Turret("play/turret-6.png", x, y,30, 50, Price, 0.5){}

void ExtraTurret::CreateBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
   
    Engine::Point normalized = diff.Normalize();
    Engine::Point normal = Engine::Point(-normalized.y, normalized.x);
    getPlayScene()->BulletGroup->AddNewObject(new DoubleDotBullet(Position + normalized * 36 - normal * 6, diff, rotation, this));
    getPlayScene()->BulletGroup->AddNewObject(new DoubleDotBullet(Position + normalized * 36 + normal * 6, diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
