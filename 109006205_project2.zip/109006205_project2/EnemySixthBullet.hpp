//
//  EnemyFryBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemySixthBullet_hpp
#define EnemySixthBullet_hpp

#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemySixthBullet : public iEnemyBullet {
public:
    explicit EnemySixthBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemySixthBullet_hpp */
