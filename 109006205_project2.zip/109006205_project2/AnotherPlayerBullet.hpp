//
//  AnotherPlayerBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef AnotherPlayerBullet_hpp
#define AnotherPlayerBullet_hpp

#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class AnotherPlayerBullet : public Bullet {
public:
    explicit AnotherPlayerBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* AnotherPlayerBullet_hpp */
