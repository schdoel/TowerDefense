//
//  ChickenBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//

#ifndef ChickenBullet_hpp
#define ChickenBullet_hpp
#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class ChickenBullet : public Bullet {
public:
    explicit ChickenBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* ChickenBullet_hpp */
