//
//  EnemyBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyBullet_hpp
#define EnemyBullet_hpp

#include <string>

#include "Sprite.hpp"

class Enemy;
class PlayScene;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyBullet : public Engine::Sprite {
protected:
    float speed;
    float damage;
    Enemy* parent;
    PlayScene* getPlayScene();
    virtual void OnExplode(Turret* turret);
public:
    Turret* Target = nullptr;
    explicit EnemyBullet(std::string img, float speed, float damage, Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void Update(float deltaTime) override;
};

#endif /* EnemyBullet_hpp */
