//
//  TurningPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef TurningPlayer_hpp
#define TurningPlayer_hpp

#include "Turret.hpp"

class TurningPlayer: public Turret {
public:
    static const int Price;
    TurningPlayer(float x, float y);
    void CreateBullet() override;
    void Update(float deltaTime) override;
};

#endif /* TurningPlayer_hpp */
