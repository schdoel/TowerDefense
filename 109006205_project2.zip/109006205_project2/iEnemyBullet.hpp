//
//  iEnemyBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef iEnemyBullet_hpp
#define iEnemyBullet_hpp

#include <string>

#include "Sprite.hpp"

class Enemy;
class PlayScene;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class iEnemyBullet : public Engine::Sprite {
protected:
    float speed;
    float damage;
    Enemy* parent;
    PlayScene* getPlayScene();
    virtual void OnExplode(Turret* turret);
public:
    Turret* Target = nullptr;
    explicit iEnemyBullet(std::string img, float speed, float damage, Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void Update(float deltaTime) override;
};

#endif /* iEnemyBullet_hpp */
