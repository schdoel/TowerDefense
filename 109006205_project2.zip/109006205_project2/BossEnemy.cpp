//
//  BossEnemy.cpp
//  allegro-test
//
//  Created by Mary Madeline on 31/05/21.
//

#include "BossEnemy.hpp"
