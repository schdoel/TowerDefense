//
//  ShieldPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef ShieldPlayer_hpp
#define ShieldPlayer_hpp

#include "Turret.hpp"

class ShieldPlayer: public Turret {
public:
    static const int Price;
    ShieldPlayer(float x, float y);
    void CreateBullet() override;
};


#endif /* ShieldPlayer_hpp */
