//
//  ShieldPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "ShieldPlayer.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int ShieldPlayer::Price = 80;
ShieldPlayer::ShieldPlayer(float x, float y) :
Turret("play/iturret-3.png", x, y,30, 50, Price, 0.5){}

void ShieldPlayer::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
    //getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    //AudioHelper::PlayAudio("gun.wav");
}
