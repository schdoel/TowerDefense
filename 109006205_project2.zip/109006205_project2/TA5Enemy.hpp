#ifndef TA5Enemy_HPP
#define TA5Enemy_HPP
#include "Enemy.hpp"

class TA5Enemy : public Enemy {
public:
    TA5Enemy(int x, int y);
    void CreateEnemyBullet() override;
};
#endif // SOFAENEMY_HPP
