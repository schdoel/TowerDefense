#include <string>

#include "AudioHelper.hpp"
#include "EnemyFifthBullet.hpp"
#include "TA5Enemy.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "SofaEnemy.hpp"

TA5Enemy::TA5Enemy(int x, int y) : Enemy("play/ienemy-5.png", x, y, 16, 120, 10, 10, 1) {
	// Use bounding circle to detect collision is for simplicity, pixel-perfect collision can be implemented quite easily,
	// and efficiently if we use AABB collision detection first, and then pixel-perfect collision.
}
void TA5Enemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemyFifthBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
