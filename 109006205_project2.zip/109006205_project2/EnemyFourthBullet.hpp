//
//  EnemyFryBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyFourthBullet_hpp
#define EnemyFourthBullet_hpp

#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyFourthBullet : public iEnemyBullet {
public:
    explicit EnemyFourthBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyFourthBullet_hpp */
