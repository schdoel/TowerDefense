//
//  ChickenEatingTurret.hpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//

#ifndef ChickenEatingTurret_hpp
#define ChickenEatingTurret_hpp
#include "Turret.hpp"

class ChickenEatingTurret: public Turret {
public:
    static const int Price;
    ChickenEatingTurret(float x, float y);
    void CreateBullet() override;
};

#endif /* ChickenEatingTurret_hpp */
