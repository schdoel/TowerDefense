//
//  NerdEnemy.cpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//
#include "AudioHelper.hpp"
#include "EnemyBasicBullet.hpp"
#include "iEnemyBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "TA1Enemy.hpp"
TA1Enemy::TA1Enemy(int x, int y) : Enemy("play/ienemy-1.png", x, y, 20, 50, 100, 50, 3) {
}

void TA1Enemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemyBasicBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
