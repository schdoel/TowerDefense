//
//  BasicPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "BasicPlayer.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "BasicPlayerBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"

const int BasicPlayer::Price = 30;
BasicPlayer::BasicPlayer(float x, float y) :
    Turret("play/iturret-11.png", x, y, 30, 30, Price, 0.75) {
    
    // Move center downward, since we the turret head is slightly biased upward.
    Anchor.y += 8.0f / GetBitmapHeight();
}
void BasicPlayer::CreateBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new BasicPlayerBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
