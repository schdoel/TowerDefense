//
//  AnotherPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "AnotherPlayer.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "AnotherPlayerBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"
#include "DoubleDotBullet.hpp"

const int AnotherPlayer::Price = 80;
AnotherPlayer::AnotherPlayer(float x, float y) :
Turret("play/iturret-4.png", x, y,30, 50, Price, 0.5){}

void AnotherPlayer::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
//    getPlayScene()->BulletGroup->AddNewObject(new AnotherPlayerBullet(Position , diff, rotation, this));
//    AudioHelper::PlayAudio("gun.wav");
}
