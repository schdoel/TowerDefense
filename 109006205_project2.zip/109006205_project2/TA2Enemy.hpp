#ifndef TA2Enemy_HPP
#define TA2Enemy_HPP
#include "Enemy.hpp"

class TA2Enemy : public Enemy {
public:
    TA2Enemy(int x, int y);
    void CreateEnemyBullet() override;
};
#endif // TA2Enemy_HPP
