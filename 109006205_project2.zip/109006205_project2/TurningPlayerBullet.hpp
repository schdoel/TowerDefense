//
//  TurningPlayerBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef TurningPlayerBullet_hpp
#define TurningPlayerBullet_hpp

#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class TurningPlayerBullet : public Bullet {
public:
    explicit TurningPlayerBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* TurningPlayerBullet_hpp */
