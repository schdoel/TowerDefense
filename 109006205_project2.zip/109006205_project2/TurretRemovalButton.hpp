//
//  TurretRemovalButton.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef TurretRemovalButton_hpp
#define TurretRemovalButton_hpp

#include "Turret.hpp"

class TurretRemovalButton: public Turret {
public:
    static const int Price;
    TurretRemovalButton(float x, float y);
    void CreateBullet() override;
    void Update(float deltaTime) override;
};

#endif /* TurretRemovalButton_hpp */
