//
//  NerdEnemy.cpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//
#include "AudioHelper.hpp"
#include "EnemyFryBullet.hpp"
#include "EnemyBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "NerdEnemy.hpp"
NerdEnemy::NerdEnemy(int x, int y) : Enemy("play/enemy-4.png", x, y, 20, 20, 100, 50, 9) {
}

void NerdEnemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemyFryBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
