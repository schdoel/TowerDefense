//
//  BombTurret.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef BombTurret_hpp
#define BombTurret_hpp

#include "Turret.hpp"

class BombTurret: public Turret {
public:
    static const int Price;
    BombTurret(float x, float y);
    void CreateBullet() override;
};


#endif /* BombTurret_hpp */
