//
//  ExtraTurret.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef ExtraTurret_hpp
#define ExtraTurret_hpp

#include "Turret.hpp"

class ExtraTurret: public Turret {
public:
    static const int Price;
    ExtraTurret(float x, float y);
    void CreateBullet() override;
};

#endif /* ExtraTurret_hpp */
