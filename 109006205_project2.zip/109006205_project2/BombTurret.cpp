//
//  BombTurret.cpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#include "BombTurret.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int BombTurret::Price = 80;
BombTurret::BombTurret(float x, float y) :
Turret("play/turret-7.png", x, y,30, 0.5, Price, 0.5){
    bomb = true;
}

void BombTurret::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
    //getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    //AudioHelper::PlayAudio("gun.wav");
}

