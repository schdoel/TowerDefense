//
//  AnotherTurret.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef AnotherTurret_hpp
#define AnotherTurret_hpp

#include "Turret.hpp"

class AnotherTurret: public Turret {
public:
    static const int Price;
    AnotherTurret(float x, float y);
    void CreateBullet() override;
};


#endif /* AnotherTurret_hpp */
