//
//  BasicPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef BasicPlayer_hpp
#define BasicPlayer_hpp

#include "Turret.hpp"

class BasicPlayer: public Turret {
public:
    static const int Price;
    BasicPlayer(float x, float y);
    void CreateBullet() override;
};

#endif /* BasicPlayer_hpp */
