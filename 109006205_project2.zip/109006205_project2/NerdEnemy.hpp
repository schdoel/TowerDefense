//
//  NerdEnemy.hpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//

#ifndef NerdEnemy_hpp
#define NerdEnemy_hpp
#include "Enemy.hpp"

class NerdEnemy : public Enemy {
public:
    NerdEnemy(int x, int y);
    void CreateEnemyBullet() override;
};

#endif /* NerdEnemy_hpp */
