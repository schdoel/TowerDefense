//
//  EnemyDotBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyDotBullet_hpp
#define EnemyDotBullet_hpp
#include "EnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyDotBullet : public EnemyBullet {
public:
    explicit EnemyDotBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyDotBullet_hpp */
