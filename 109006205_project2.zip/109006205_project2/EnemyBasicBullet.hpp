//
//  EnemyDotBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyBasicBullet_hpp
#define EnemyBasicBullet_hpp
#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyBasicBullet : public iEnemyBullet {
public:
    explicit EnemyBasicBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyBasicBullet_hpp */
