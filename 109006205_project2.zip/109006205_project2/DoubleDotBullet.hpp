//
//  DoubleDotBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 31/05/21.
//

#ifndef DoubleDotBullet_hpp
#define DoubleDotBullet_hpp

#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class DoubleDotBullet : public Bullet {
public:
    explicit DoubleDotBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
    void OnExplode(Enemy* enemy) override;
};

#endif /* DoubleDotBullet_hpp */
