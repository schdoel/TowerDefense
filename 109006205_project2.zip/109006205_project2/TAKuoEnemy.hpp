#ifndef TAKuoEnemy_HPP
#define TAKuoEnemy_HPP
#include "Enemy.hpp"

class TAKuoEnemy : public Enemy {
public:
    TAKuoEnemy(int x, int y);
    void CreateEnemyBullet() override;
};
#endif // STAKuoEnemy_HPP
