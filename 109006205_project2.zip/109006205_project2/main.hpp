//
//  main.hpp
//  allegro-test
//
//  Created by Mary Madeline on 24/05/21.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
