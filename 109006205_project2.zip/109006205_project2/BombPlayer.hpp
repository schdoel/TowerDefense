//
//  BombPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef BombPlayer_hpp
#define BombPlayer_hpp

#include "Turret.hpp"

class BombPlayer: public Turret {
public:
    static const int Price;
    BombPlayer(float x, float y);
    void CreateBullet() override;
};

#endif /* BombPlayer_hpp */
