//
//  EnemyFryBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyFryBullet_hpp
#define EnemyFryBullet_hpp

#include "EnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyFryBullet : public EnemyBullet {
public:
    explicit EnemyFryBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyFryBullet_hpp */
