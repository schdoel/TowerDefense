//
//  intro.cpp
//  allegro-test
//
//  Created by Mary Madeline on 06/06/21.
//

#include "intro6.hpp"
#include "GameEngine.hpp"
#include "Group.hpp"
#include "IScene.hpp"
#include "Start_Scene.hpp"
#include "Resources.hpp"
// TODO 3 (2/2): You can imitate the 2 files: '"ExplosionEffect.hpp', '"ExplosionEffect.cpp' to create a Shoot Effect.

intro6::intro6(float x, float y) : Sprite("start_scene/ex4-1.png", x, y), timeTicks(0) {
    for (int i = 1; i <= 3; i++) {
        bmps.push_back(Engine::Resources::GetInstance().GetBitmap("start_scene/ex4-" + std::to_string(i) + ".png"));
    }
}
void intro6::Update(float deltaTime) {
    timeTicks += deltaTime;
    if (timeTicks >= timeSpan) {
        timeTicks=0;
    }
    int phase = floor(timeTicks / timeSpan * bmps.size());
    bmp = bmps[phase];
    Sprite::Update(deltaTime);
}
