//
//  ChickenEatingTurret.cpp
//  allegro-test
//
//  Created by Mary Madeline on 27/05/21.
//

#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "ChickenEatingTurret.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int ChickenEatingTurret::Price = 80;
ChickenEatingTurret::ChickenEatingTurret(float x, float y) :
Turret("play/turret-3.png", x, y,30, 40, Price, 0.5){}

void ChickenEatingTurret::CreateBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
