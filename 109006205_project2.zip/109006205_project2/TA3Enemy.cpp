#include <string>

#include "AudioHelper.hpp"
#include "EnemyThirdBullet.hpp"
#include "TA3Enemy.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "SofaEnemy.hpp"

TA3Enemy::TA3Enemy(int x, int y) : Enemy("play/ienemy-3.png", x, y, 16, 100, 10, 10, 1) {
	// Use bounding circle to detect collision is for simplicity, pixel-perfect collision can be implemented quite easily,
	// and efficiently if we use AABB collision detection first, and then pixel-perfect collision.
}
void TA3Enemy::CreateEnemyBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new EnemyThirdBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
