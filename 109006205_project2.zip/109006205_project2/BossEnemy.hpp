//
//  BossEnemy.hpp
//  allegro-test
//
//  Created by Mary Madeline on 31/05/21.
//

#ifndef BossEnemy_hpp
#define BossEnemy_hpp

#include <stdio.h>

#endif /* BossEnemy_hpp */
