//
//  MakeSlowPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#ifndef MakeSlowPlayer_hpp
#define MakeSlowPlayer_hpp

#include "Turret.hpp"

class MakeSlowPlayer: public Turret {
public:
    static const int Price;
    MakeSlowPlayer(float x, float y);
    void CreateBullet() override;
};
#endif /* MakeSlowPlayer_hpp */
