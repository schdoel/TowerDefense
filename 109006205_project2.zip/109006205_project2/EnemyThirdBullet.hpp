//
//  EnemyFryBullet.hpp
//  allegro-test
//
//  Created by Mary Madeline on 30/05/21.
//

#ifndef EnemyThirdBullet_hpp
#define EnemyThirdBullet_hpp

#include "iEnemyBullet.hpp"

class Enemy;
class Turret;
namespace Engine {
struct Point;
}  // namespace Engine

class EnemyThirdBullet : public iEnemyBullet {
public:
    explicit EnemyThirdBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Enemy* parent);
    void OnExplode(Turret* turret) override;
};

#endif /* EnemyThirdBullet_hpp */
