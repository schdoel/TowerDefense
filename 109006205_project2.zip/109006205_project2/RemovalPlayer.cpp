//
//  RemovalPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "RemovalPlayer.hpp"
#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

#include "Collider.hpp"
//#include "Turret.hpp"
//#include "GameEngine.hpp"
//#include "Group.hpp"
#include "IObject.hpp"
#include "IScene.hpp"
//#include "PlayScene.hpp"
#include "Sprite.hpp"

const int RemovalPlayer::Price = 0;
RemovalPlayer::RemovalPlayer(float x, float y) :
Turret("play/bomb.png", x, y, 30, 50, Price, 0.5){
    remove = true;
}

void RemovalPlayer::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
    //getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    //AudioHelper::PlayAudio("gun.wav");
}

void RemovalPlayer::Update(float deltaTime){
    Sprite::Update(deltaTime);
    PlayScene* scene = getPlayScene();
    
    if(Enabled == true){
        for (auto& it : scene->TowerGroup->GetObjects()) {
            Turret* turret = dynamic_cast<Turret*>(it);
            if (!turret->Visible)
                continue;
            if (Engine::Collider::IsCircleOverlap(Position, CollisionRadius, turret->Position, turret->CollisionRadius)) {
                turret->Hit(INFINITY);
                return;
            }
        }
    }
    
}
