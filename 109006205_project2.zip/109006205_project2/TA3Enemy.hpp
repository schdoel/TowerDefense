#ifndef TA3Enemy_HPP
#define TA3Enemy_HPP
#include "Enemy.hpp"

class TA3Enemy : public Enemy {
public:
    TA3Enemy(int x, int y);
    void CreateEnemyBullet() override;
};
#endif // TA3Enemy_HPP
