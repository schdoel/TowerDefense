#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "ShieldTurret.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int ShieldTurret::Price = 80;
ShieldTurret::ShieldTurret(float x, float y) :
Turret("play/turret-5.png", x, y,30, 50, Price, 0.5){}

void ShieldTurret::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
    //getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    //AudioHelper::PlayAudio("gun.wav");
}
