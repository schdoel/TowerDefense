#ifndef TA4Enemy_HPP
#define TA4Enemy_HPP
#include "Enemy.hpp"

class TA4Enemy : public Enemy {
public:
    TA4Enemy(int x, int y);
    void CreateEnemyBullet() override;
};
#endif // TA4Enemy_HPP
