//
//  BombPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "BombPlayer.hpp"

#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "ChickenBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int BombPlayer::Price = 80;
BombPlayer::BombPlayer(float x, float y) :
Turret("play/iturret-5.png", x, y,30, 0.5, Price, 0.5){
    bomb = true;
    ibomb = true;
}

void BombPlayer::CreateBullet() {
//    Engine::Point diff = Engine::Point(1,0);
//    float rotation = ALLEGRO_PI / 2;
    //getPlayScene()->BulletGroup->AddNewObject(new ChickenBullet(Position , diff, rotation, this));
    //AudioHelper::PlayAudio("gun.wav");
}



