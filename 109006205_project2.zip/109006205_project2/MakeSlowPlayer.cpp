//
//  MakeSlowPlayer.cpp
//  allegro-test
//
//  Created by Mary Madeline on 02/06/21.
//

#include "MakeSlowPlayer.hpp"

#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "MakeSlowPlayerBullet.hpp"
#include "Group.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "ShootEffect.hpp"

const int MakeSlowPlayer::Price = 80;
MakeSlowPlayer::MakeSlowPlayer(float x, float y) :
Turret("play/iturret-2.png", x, y,30, 40, Price, 0.25){}

void MakeSlowPlayer::CreateBullet() {
    Engine::Point diff = Engine::Point(1,0);
    float rotation = ALLEGRO_PI / 2;
    getPlayScene()->BulletGroup->AddNewObject(new MakeSlowPlayerBullet(Position , diff, rotation, this));
    AudioHelper::PlayAudio("gun.wav");
}
