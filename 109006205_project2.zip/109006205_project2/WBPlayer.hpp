//
//  WBPlayer.hpp
//  allegro-test
//
//  Created by Mary Madeline on 03/06/21.
//

#ifndef WBPlayer_hpp
#define WBPlayer_hpp

#include "Turret.hpp"

class WBPlayer: public Turret {
public:
    static const int Price;
    WBPlayer(float x, float y);
    void CreateBullet() override;
};

#endif /* WBPlayer_hpp */
